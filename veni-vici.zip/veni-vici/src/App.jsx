import { useState } from 'react';
import './App.css';
import DisplayCard from './components/DisplayCard';
import BanList from './components/BanList';

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function App() {
  const [item, setItem] = useState(null);
  const [banList, setBanList] = useState([]);

  const fetchDog = async () => {
    try {
      const headers = {
        "x-api-key": import.meta.env.VITE_DOG_API_KEY, // make sure .env is set up!
      };

      let dog = null;

      while (!dog) {
        const res = await fetch("https://api.thedogapi.com/v1/images/search?has_breeds=true", { headers });
        const data = await res.json();

        if (!data || !data[0]?.breeds || data[0].breeds.length === 0) {
          console.warn("No valid breed found, retrying...");
          await wait(300); // avoid hitting the API too fast
          continue;
        }

        const breed = data[0].breeds[0];
        const origin = breed.origin || "Unknown";

        if (!banList.includes(origin)) {
          dog = {
            name: breed.name,
            origin: origin,
            lifespan: breed.life_span,
            image: data[0].url,
          };
        } else {
          await wait(300); // wait before retrying if banned
        }
      }

      setItem(dog);
    } catch (err) {
      console.error("Error fetching dog:", err);
    }
  };

  const handleBan = (origin) => {
    if (!banList.includes(origin)) {
      setBanList((prev) => [...prev, origin]);
    }
  };

  const handleUnban = (origin) => {
    setBanList((prev) => prev.filter((item) => item !== origin));
  };

  return (
    <div className="App">
      <h1>Veni Vici <span role="img" aria-label="paw prints">🐾</span></h1>
      <button onClick={fetchDog}>Discover!</button>

      {item && <DisplayCard item={item} handleBan={handleBan} />}
      {banList.length > 0 && <BanList banList={banList} handleUnban={handleUnban} />}
    </div>
  );
}

export default App;
