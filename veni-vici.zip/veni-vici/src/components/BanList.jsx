const BanList = ({ banList, handleUnban }) => {
  return (
    <div className="ban-panel">
      <h3>Ban List</h3>
      <p>Select an attribute in your listing to ban it</p>
      {banList.map((origin, index) => (
        <div
          key={index}
          className="ban-pill"
          onClick={() => handleUnban(origin)}
        >
          {origin}
        </div>
      ))}
    </div>
  );
};

export default BanList;
