// src/components/Flashcard.jsx
import React, { useState } from "react";
import "../styles.css";

export default function Flashcard({ question, answer, image, onCorrect }) {
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [flipped, setFlipped] = useState(false);

  const checkAnswer = (e) => {
    e.preventDefault(); // Prevents form submission from refreshing the page
    if (userAnswer.trim().toLowerCase() === answer.toLowerCase()) {
      setFeedback("✅ Correct!");
      onCorrect(); // Update score if correct
    } else {
      setFeedback("❌ Incorrect! Try again.");
    }
    setFlipped(true); // Auto-flip on submission
  };

  const resetCard = () => {
    setFlipped(false);
    setUserAnswer("");
    setFeedback("");
  };

  return (
    <div className="flashcard-container">
      <div className={`flashcard ${flipped ? "flipped" : ""}`} onClick={resetCard}>
        {!flipped ? (
          <div className="flashcard-front">
            {image && (
              <img
                src={image}
                alt={question}
                className="flashcard-image"
                onError={(e) => (e.target.style.display = "none")}
              />
            )}
            <h2 className="flashcard-question">{question}</h2>
          </div>
        ) : (
          <div className="flashcard-back">
            <p className="flashcard-answer">{answer}</p>
            <input
              type="text"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              placeholder="Place your answer here..."
              className="answer-input"
            />
            <button onClick={checkAnswer} className="submit-button">Submit Guess</button>
            <p className="feedback">{feedback}</p>
          </div>
        )}
      </div>
    </div>
  );
}
