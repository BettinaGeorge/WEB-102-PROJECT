import React, { useState } from "react";
import "../styles.css";

export default function Flashcard({ question, answer, image, onCorrect, onNext, onPrev }) {
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [flipped, setFlipped] = useState(false);

  const checkAnswer = () => {
    if (userAnswer.trim().toLowerCase() === answer.toLowerCase()) {
      setFeedback("✅ Correct!");
      onCorrect(); // Update score if correct
    } else {
      setFeedback("❌ Incorrect! Try again.");
    }
    setFlipped(true); // Flip the card to show answer
  };

  return (
    <div className={`flashcard-container ${flipped ? "flipped" : ""}`} onClick={() => setFlipped(!flipped)}>
      <div className="flashcard">
        {flipped ? (
          <div className="flashcard-back">
            <h2 className="flashcard-answer">{answer}</h2>
          </div>
        ) : (
          <div className="flashcard-front">
            {image && (
              <img
                src={image}
                alt={question}
                className="flashcard-image"
                onError={(e) => (e.target.style.display = "none")}
              />
            )}
            <h2 className="flashcard-question">{question}</h2>
            <input
              type="text"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              placeholder="Place your answer here..."
              className="answer-input"
            />
            <button onClick={checkAnswer} className="submit-button">Submit Guess</button>
            <p className="feedback">{feedback}</p>
          </div>
        )}
      </div>
      <div className="navigation-buttons">
        <button onClick={onPrev} className="nav-button">⬅️ Back</button>
        <button onClick={onNext} className="nav-button">Next ➡️</button>
      </div>
    </div>
  );
}